package com.example.switch4p1;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    TextView tv;
    Switch sw1, sw2, sw3;
    LinearLayout layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            // v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        tv = (TextView) findViewById(R.id.tv1);
        sw1 = (Switch) findViewById(R.id.switch1);
        sw2 = (Switch) findViewById(R.id.switch2);
        sw3 = (Switch) findViewById(R.id.switch3);
        layout = (LinearLayout) findViewById(R.id.main);

    }

    public void onSwitch(View view) {
        int id = view.getId();

        if (id == R.id.switch1) { //lub sw1.getId()
            if(sw1.isChecked())
                tv.setVisibility(view.VISIBLE);
            else
                tv.setVisibility(view.INVISIBLE);
        } else if (id == R.id.switch2) {
            if(sw1.isChecked())
                tv.setTextSize(20);
            else
                tv.setTextSize(34);
        } else if(id == R.id.switch3) {
            if(sw1.isChecked()) {
                tv.setTextAppearance(R.style.tv_bright);
                //layout.setBackgroundColor(Color.YELLOW);
                layout.setBackgroundColor(Color.parseColor("#EFC752"));
            } else {
                tv.setTextAppearance(R.style.tv_dark);
                layout.setBackgroundColor(Color.GREEN);
            }
        }
    }
}