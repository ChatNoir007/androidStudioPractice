package com.example.obliczenia4p1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    EditText ed1, ed2, ed3;
    RadioButton rb1, rb2, rb3;
    TextView tv4;
    Button btn1, btn2;
    int a, b, c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ed1 = (EditText) findViewById(R.id.editText1);
        ed2 = (EditText) findViewById(R.id.editText2);
        ed3 = (EditText) findViewById(R.id.editText3);
        rb1 = (RadioButton) findViewById(R.id.radioButton1);
        rb2 = (RadioButton) findViewById(R.id.radioButton2);
        rb3 = (RadioButton) findViewById(R.id.radioButton3);
        tv4 = (TextView) findViewById(R.id.textView4);
        btn1 = (Button) findViewById(R.id.button1);
        btn2 = (Button) findViewById(R.id.button2);

    }

    public void random(View view) {
        Random rnd = new Random();

        int c = 1 + rnd.nextInt(50);

        ed3.setText(""+c);
    }

    public void check(View view) {
        if(rb1.isChecked()) { //robienie NWD

        }
        if(rb2.isChecked()) { //robienie Pola trójkąta, zrób obsługę czy możliwy do stworzenia

        }
        if(rb3.isChecked()) { //robienie najmniejszej odległości między czymś średnie czxca

        }
    }

}